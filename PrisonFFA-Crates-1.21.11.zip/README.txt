PrisonFFA Crates - Minecraft Java 1.21.11

INSTALLAZIONE
1. Copia PrisonFFA-Crates-1.21.11.zip nella cartella resourcepacks del client.
2. Attiva il pack nelle Opzioni > Pacchetti risorse.
3. Per distribuirlo dal server, configura l'URL del pack nelle impostazioni del server.

ITEM BASE E CUSTOM MODEL DATA
Le crate sono item grafici basati su minecraft:paper. Il resource pack seleziona
la texture in base alla prima stringa di minecraft:custom_model_data:

  crate_common     Comune, legno e smeraldo
  crate_rare       Rara, acciaio e cristallo azzurro
  crate_epic       Epica, ametista e metallo viola
  crate_legendary  Leggendaria, magma e oro

COMANDI DI PROVA (da eseguire in gioco)
/give @s minecraft:paper[minecraft:custom_model_data={strings:["crate_common"]}] 1
/give @s minecraft:paper[minecraft:custom_model_data={strings:["crate_rare"]}] 1
/give @s minecraft:paper[minecraft:custom_model_data={strings:["crate_epic"]}] 1
/give @s minecraft:paper[minecraft:custom_model_data={strings:["crate_legendary"]}] 1

Le normali carte non personalizzate mantengono il modello originale. Questo
resource pack fornisce solo texture e modelli: il plugin PrisonFFA non include
ancora apertura delle crate, ricompense o assegnazione automatica dei modelli.

COLLEGAMENTO CON EXCELLENTCRATES
ExcellentCrates usa un item personalizzato come "Inventory Item" della crate.
Per ciascun tier:
1. Attiva il resource pack sul client (o distribuiscilo dal server).
2. Esegui in gioco il comando /give corrispondente qui sopra.
3. Apri /crates editor, entra in Crates e seleziona o crea la crate.
4. Apri Appearance e imposta l'item ricevuto come Inventory Item.
   Il modello/texture dipende dal componente CustomModelData: crate_common,
   crate_rare, crate_epic oppure crate_legendary.
5. Salva la crate. Distribuisci l'item collegato con il comando di ExcellentCrates:
   /crates give <player> <crate_id> [amount]

Importante: il comando /give serve solo per fornire all'editor l'item grafico.
Per dare ai giocatori una crate funzionante, usa /crates give dopo aver salvato
la configurazione. L'icona si vede solo ai giocatori che hanno caricato il pack.
